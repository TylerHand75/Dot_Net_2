/* check whether the data base exists; if so drop it*/
IF EXISTS(SELECT 1 from master.dbo.sysdatabases
			WHERE name = 'cabin_db_am')
BEGIN
	DROP DATABASE cabin_db_am
	print '' print'***dropping database cabin_db_am'
END 
GO 

print '' print'***creating database cabin_db_am'
GO
CREATE DATABASE cabin_db_am
GO

print '' print'*** using cabin_db_am'
GO
use [cabin_db_am] 
GO


/* employee table*/
print '' print'*** creating employee table'
GO
CREATE table [dbo].[Employee](
	[EmployeeID] 	[int] identity  (100000,1) 	NOT NULL,
	[GivenName]  	[nvarchar]		(50)		NOT NULL,
	[FamilyName] 	[nvarchar] 		(100)		NOT NULL,
	[Phone]		 	[nvarchar]		(13)		NOT NULL,
	[Email] 	 	[nvarchar]	   	(100)		NOT NULL,
	[PasswordHash] 	[nvarchar]		(100)		NOT NULL DEFAULT  
		'9c9064c59f1ffa2e174ee754d2979be80dd30db552ec03e7e327e9b1a4bd594e',
	[Active]		[bit]						NOT NULL DEFAULT 1,
	CONSTRAINT [pk_EmployeeID] PRIMARY KEY([EmployeeID]),
	CONSTRAINT[ak_Email] UNIQUE ([Email])
 )
 /*employee test records*/
 print '' print'*** creating employee test records'
GO
INSERT into [dbo].[Employee]
	([GivenName],[FamilyName],[Phone],[Email])
		VALUES
		('Joanne','smith','3195551111', 'joanne@company.com'),
		('Martin','Jones','319555222', 'martin@company.com'),
		('Leo','Williams','3195553333', 'leo@company.com'),
		('Mary','Joe','3195554444', 'mary@company.com'),
		('ben','diver','3195555555', 'ben@company.com')
GO

print '' print'*** creating Roles table'
GO
CREATE table [dbo].[Role](
	[RoleID] 		[nvarchar]	(50) 	NOT NULL,
	[Descrpition] 	[nvarchar] 	(500) 	NULL,
	CONSTRAINT [pk_RoleID] PRIMARY KEY ([RoleID])
)
GO
print '' print'*** inserting Roles records'
GO
INSERT INTO [dbo].[Role]
	([RoleID],[Descrpition])
	VALUES 
		('Admin', 'administraters user accounts'),
		('Manager', 'magages inventory '),
		('Rental', 'rents out the rooms'),
		('CheckIn', 'checks in people '),
		('CheckOut', 'checks guests out '),
		('Inspection', 'inspects rooms for damage'),
		('Prep', 'cleans the rooms'),
		('Maintenance', 'fixes any issuses they have in the rooms')
GO

/*Employee role joins the role and employee tables*/
print '' print '*** Creating the join table of role and epmloyee'
GO
CREATE TABLE [dbo].[EmployeeRole](
		[EmployeeID] 	[int]  				NOT NULL,
		[RoleID] 		[nvarchar]	(50) 	NOT NULL,
		CONSTRAINT [fk__EmployeeRole_EmployeeID] FOREIGN KEY([EmployeeID])
			REFERENCES [dbo].[Employee]([EmployeeID]),
		CONSTRAINT [fk__EmployeeRole_RoleID] FOREIGN KEY([RoleID])
			REFERENCES [dbo].[Role]([RoleID]),
		CONSTRAINT [pk_EmployeeRole] PRIMARY KEY ([EmployeeID],[RoleID])
)
GO 

print '' print '*** inserting sample employeeRole records;'
GO
INSERT INTO [dbo].[EmployeeRole]
		([EmployeeID],[RoleID])
		VALUES
		(100000, 'Admin'),
		(100000, 'Manager'),
		(100001, 'Rental'),
		(100002, 'CheckIn'),
		(100002, 'CheckOut'),
		(100003, 'Inspection'),
		(100003, 'Prep'),
		(100004, 'Maintenance')
GO


/*Login relative stored procedures*/

print '' print '*** creating sp_authenticate_user '
GO
CREATE PROCEDURE [dbo].[sp_authenticate_user] 
(
	@Email 			[nvarchar] 	(100),
	@PasswordHash 	[nvarchar]	(100)
)
AS

	BEGIN
		SELECT COUNT([EmployeeID]) AS 'Authenticated'
		FROM [Employee] 
		WHERE @Email = [Email]
			AND @PasswordHash = [PasswordHash]
			AND [Active] = 1
	
	END
	
GO


print '' print '*** creating sp_select_employee_by_email '
GO
CREATE PROCEDURE [dbo].[sp_select_employee_by_email]
(
	@Email 			[nvarchar] 	(100)
)
AS

	BEGIN
		SELECT [EmployeeID][Email],[GivenName],[FamilyName],[Phone]
		FROM [Employee]           
		WHERE @Email = [Email]
	END
	
GO
print '' print '*** creating sp_select_roles_by_employeeID '
GO
CREATE PROCEDURE [dbo].[sp_select_roles_by_employeeID]
(
	@EmployeeID			[int] 	
)
AS

	BEGIN
		SELECT [RoleID]
		FROM [EmployeeRole]           
		WHERE @EmployeeID = [EmployeeID]
	END
	
GO