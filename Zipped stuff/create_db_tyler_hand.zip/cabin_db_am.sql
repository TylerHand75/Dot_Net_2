/* check whether the data base exists; if so drop it*/
if exists(SELECT 1 from MASTER.dbo.sysdatabases
			WHERE name - cabin_db_am)
BEGIN
	DROP DATABASE cabin_db_am
	print '' print'***dropping database cabin_db_am'
end 
GO 

print '' print'***creating database cabin_db_am'
GO
CREATE DATABASE cabin_db_am
GO

print '' print'*** using cabin_db_am'
GO
use [cabin_db_am] 
GO


/* employee table*/
print '' print'*** creating employee table'
GO
CREATE table [dbo].[Employee](
	[EmployeeID] 	[int] identity  (100000,1) 	NOT NULL,
	[GivenName]  	[nvarchar]		(50)		NOT NULL,
	[FamilyName] 	[nvarchar] 		(100)		NOT NULL,
	[Phone]		 	[nvarchar]		(13)		NOT NULL,
	[Email] 	 	[nvarchar]	   	(100)		NOT NULL,
	[PasswordHash] 	[nvarchar]		(100)		NOT NULL DEFAULT  
		'9c9064c59f1ffa2e174ee754d2979be80dd30db552ec03e7e327e9b1a4bd594e',
	[Active]		[bit]						NOT NULL DEFAULT 1,
	CONSTRAINT [pk_EmployeeID] PRIMARY KEY([EmployeeID]),
	CONSTRAINT[ak_Email] UNIQUE ([Email])
 )