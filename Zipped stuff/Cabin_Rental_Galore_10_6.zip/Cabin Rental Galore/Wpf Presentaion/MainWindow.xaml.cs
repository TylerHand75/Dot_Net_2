﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataObjects;
using LogicLayer;
using LogicLayerInterfaces;

namespace Wpf_Presentaion
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private User _user = null; 
        
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            IUserManager userManager = new UserManager();

            string email = txtEmail.Text;
            string password = txtPassword.Password;

            if (email.Length < 6 )
            {
                MessageBox.Show("Invalid email address");
                txtEmail.Text = " ";
                txtEmail.Focus();
                return; 
            }
            if (password == "")
            {
                MessageBox.Show("You must enter password");
                txtPassword.Focus();
                return;
            }
            try
            {
                _user = userManager.LoginUser(email, password);
                MessageBox.Show("Welcome" + _user.GivenName + "\n" + "You are Logged in as " + _user.Roles[0]);
                showTabsForUser();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n\n" + ex.InnerException.Message);
            }
        }

        private void FrmMain_Loaded(object sender, RoutedEventArgs e)
        {
            txtEmail.Focus();
            hideAllUserTabs();
        }
        private void showTabsForUser()
        {
            foreach (var role in _user.Roles)
            {
                switch (role)
                {
                    case "Rental":
                        tabRental.Visibility = Visibility.Visible;
                        tabRental.IsSelected = true;
                        break;
                    case "CheckIn":
                        tabRental.Visibility = Visibility.Visible;
                        tabRental.IsSelected = true;
                        break;

                    case "CheckOut":
                        tabRental.Visibility = Visibility.Visible;
                        tabRental.IsSelected = true;
                        break;

                    case "Cabin Inspaction":
                        tabRental.Visibility = Visibility.Visible;
                        tabRental.IsSelected = true;
                        break;

                    case "Prep for Rental":
                        tabRental.Visibility = Visibility.Visible;
                        tabRental.IsSelected = true;
                        break;
                    case "Cabin Maintanace":
                        tabRental.Visibility = Visibility.Visible;
                        tabRental.IsSelected = true;
                        break;
                    case "Administration":
                        tabRental.Visibility = Visibility.Visible;
                        tabRental.IsSelected = true;
                        break;
                    case "Cabin Managment":
                        tabRental.Visibility = Visibility.Visible;
                        tabRental.IsSelected = true;
                        break;
                    default:
                        break;
                }
                pnlTabs.Visibility = Visibility.Visible;
            }
        }
        private void hideAllUserTabs()
        {
            pnlTabs.Visibility = Visibility.Hidden;
            foreach (var tab in tabsetMain.Items)
            {
                ((TabItem)tab).Visibility = Visibility.Collapsed;
            }
        }
    }
}
