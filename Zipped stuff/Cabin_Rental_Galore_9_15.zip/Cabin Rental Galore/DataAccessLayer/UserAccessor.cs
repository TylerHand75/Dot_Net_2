﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataObjects;
using DataAccessLayerInterfaces;

namespace DataAccessLayer
{
    public class UserAccessor : IUserAccessor
    {
        public int AuthenticateUserWIthEmailAndPasswordHash(string email, string passwordHash)
        {
            throw new NotImplementedException();
        }

        public User SelectUserByEmail(string email)
        {
            throw new NotImplementedException();
        }

        public List<string> SelestRolesByEmployeeID(int employeeID)
        {
            throw new NotImplementedException();
        }

        public int UpdatePasswordHanh(int employeeID, string passwordHash, string oldPasswordHash)
        {
            throw new NotImplementedException();
        }
    }
}
