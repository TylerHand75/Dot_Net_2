﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataObjects;
using LogicLayerInterfaces;


namespace LogicLayer
{
    public class UserManager : IUserManager
    {
        public string HashSha256(string source)
        {
            throw new NotImplementedException();
        }

        public User LoginUser(string email, string password)
        {
            throw new NotImplementedException();
        }

        public bool ResetPassword(string email, string password, string newPassword)
        {
            throw new NotImplementedException();
        }
    }
}
