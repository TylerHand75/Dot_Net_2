﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataObjects;
using LogicLayer;
using LogicLayerInterfaces;

namespace Wpf_Presentaion
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private User _user = null; 
        
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            IUserManager userManager = new UserManager();

            string email = txtEmail.Text;
            string password = txtPassword.Password;

            if (email.Length < 6 )
            {
                MessageBox.Show("Invalid email address");
                txtEmail.Text = " ";
                txtEmail.Focus();
                return; 
            }
            if (password == "")
            {
                MessageBox.Show("You must enter password");
                txtPassword.Focus();
                return;
            }
            try
            {
                _user = userManager.LoginUser(email, password);
                MessageBox.Show("Welcome" + _user.GivenName + "\n" + "You are Logged in as " + _user.Roles[0]);
                showTabsForUser();
                updateUIForUser();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n\n" + ex.InnerException.Message);
            }
        }
       


        private void FrmMain_Loaded(object sender, RoutedEventArgs e)
        {
            txtEmail.Focus();
            hideAllUserTabs();
            btnLogin.IsDefault = true;
            
        }
        private void showTabsForUser()
        {
            foreach (var role in _user.Roles)
            {
                switch (role)
                {
                    case "Rental":
                        tabRental.Visibility = Visibility.Visible;
                        tabRental.IsSelected = true;
                        break;
                    case "CheckIn":
                        tabCheckIn.Visibility = Visibility.Visible;
                        tabCheckIn.IsSelected = true;
                        break;

                    case "CheckOut":
                        tabCheckOut.Visibility = Visibility.Visible;
                        tabCheckOut.IsSelected = true;
                        break;

                    case "Inspection":
                        tabInspection.Visibility = Visibility.Visible;
                        tabInspection.IsSelected = true;
                        break;

                    case "Prep":
                        tabPrep.Visibility = Visibility.Visible;
                        tabPrep.IsSelected = true;
                        break;
                    case "Maintenance":
                        tabMaintiance.Visibility = Visibility.Visible;
                        tabMaintiance.IsSelected = true;
                        break;
                    case "Admin":
                        tabAdmin.Visibility = Visibility.Visible;
                        tabAdmin.IsSelected = true;
                        break;
                    case "Manager":
                        tabmanagment.Visibility = Visibility.Visible;
                        tabmanagment.IsSelected = true;
                        break;
                    default:
                        break;
                }
                pnlTabs.Visibility = Visibility.Visible;
            }
        }
        private void hideAllUserTabs()
        {
            pnlTabs.Visibility = Visibility.Hidden;
            foreach (var tab in tabsetMain.Items)
            {
                ((TabItem)tab).Visibility = Visibility.Collapsed;
            }
        }
        private void hideLogin()
        {
            
        }
        private void updateUIForLogoit()
        {

        }
        private void updateUIForUser()
        {
            string rolesList = " ";

            for (int i = 0; i  <  _user.Roles.Count; i++)
            {
                rolesList += " " + _user.Roles[i];

                if (i == _user.Roles.Count - 2)
                {
                    if (_user.Roles.Count > 2 )
                    {
                        rolesList += " ,";
                    }
                    rolesList += "  and ";
                }else if (i < _user.Roles.Count - 2) 
                {
                    rolesList += " ,";
                }
            }
            lblGreeting.Content = "Welcome, "  + _user.GivenName  + " " +  _user.FamilyName  +  " you are logged in as : "  + rolesList  +  ".";

            statMessage.Content = "Logged in on " + DateTime.Now.ToLongDateString() + "," +
                DateTime.Now.ToShortDateString() + " Please log out before you leave ";


            txtEmail.Text = "";
            txtPassword.Password = "";

            txtEmail.Visibility = Visibility.Hidden;
            txtPassword.Visibility = Visibility.Hidden;
            lblEmail.Visibility = Visibility.Hidden;
            lblPassword.Visibility = Visibility.Hidden;

            btnLogin.Content = "Log Out";
            btnLogin.IsDefault = false;
        }
        
    }
}
