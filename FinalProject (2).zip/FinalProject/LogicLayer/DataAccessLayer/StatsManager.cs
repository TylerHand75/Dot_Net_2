﻿using DataAccessLayerInterfaces;

namespace DataAccessLayer
{
    internal class StatsManager : IStatsAccessor
    {
    }
}