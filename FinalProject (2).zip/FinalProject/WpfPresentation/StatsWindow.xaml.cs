﻿using DataObjects;
using LogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfPresentation
{
    
    public partial class StatsWindow : Window
    {
       StatsVM _stats = null;
       StatsManager _statsManager = null;
        
        public StatsWindow(StatsVM stats, StatsManager statsManager)
        {

            _stats = stats;
            InitializeComponent();

        }
        private void Window_Loaded(object sender, RoutedEventArgs ev)
        {
            txtUserID.Text = _stats.UserID.ToString();
            txtName.Text = _stats.Name.ToString();
            txtRank.Text = _stats.Ranks;
            txtKDRatio.Text = _stats.KDRatio.ToString();
            txtACS.Text = _stats.ACS.ToString();


        }
    }
}
