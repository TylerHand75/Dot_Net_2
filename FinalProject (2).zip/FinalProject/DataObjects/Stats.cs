﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataObjects
{
    public class Stats
    {
        public int UserID { get; set; }
        public int RankID { get; set; }
        public string Name { get; set; }

        public string Ranks { get; set; }
        public decimal KDRatio {get; set;}
        public int ACS { get; set; }
    }
    public class StatsVM : Stats
    {
        public List<string>PlayerStats {get; set;}
        
    }
}
