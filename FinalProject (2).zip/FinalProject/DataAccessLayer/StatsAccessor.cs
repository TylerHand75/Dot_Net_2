﻿using DataObjects;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayerInterfaces;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace DataAccessLayer
{
    public class StatsAccessor : IStatsAccessor
    {


        public List<string> SelectStatsByUserID(List<string> stats)
        {
            List<string> playerName = new List<string>();

            var connectionFactory = new DBConnection();
            var conn = connectionFactory.GetConnection();

            var cmdText = "sp_select_Stats_by_UserID";

            var cmd = new SqlCommand(cmdText, conn);

            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@UserID", SqlDbType.Int);
            cmd.Parameters["@UserID"].Value = playerName;

            try
            {
                conn.Open();

                var reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        playerName.Add(reader.GetString(0));
                    }
                }
                else
                {
                    throw new ArgumentException("Invalid User");
                }
            }
            catch (Exception up)
            {
                throw up;
            }
            finally
            {
                conn.Close();
            }

            return playerName;
        }


        public List<StatsVM> SelectStatsByUserID(string userStats)
        {
            List<StatsVM> stats = new List<StatsVM>();


            var connectionFactory = new DBConnection();
            var conn = connectionFactory.GetConnection();


            var cmdText = "sp_select_Stats_by_UserID";


            var cmd = new SqlCommand(cmdText, conn);


            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@RankID", SqlDbType.NVarChar, 25);
            cmd.Parameters["@RankID"].Value = userStats;

            try
            {

                conn.Open();


                var reader = cmd.ExecuteReader();


                if (reader.HasRows)
                {
                    while (reader.Read())
                    {

                        var stat = new StatsVM();
                        stat.UserID = reader.GetInt32(0);
                        stat.RankID = reader.GetInt32(1);
                        stat.Name = reader.GetString(2);
                        stat.Ranks = reader.GetString(3);
                        stat.KDRatio = reader.GetDecimal(4);
                        stat.ACS = reader.GetInt32(5);

                        stats.Add(stat);

                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conn.Close();
            }

            return stats;
        }
    }
}



