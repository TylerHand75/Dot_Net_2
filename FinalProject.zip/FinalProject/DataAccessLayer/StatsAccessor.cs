﻿using DataObjects;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayerInterfaces;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace DataAccessLayer
{
    public class StatsAccessor : IStatsAccessor
    {
        public List<StatsVM> SelectStatsByUserID(string userStats)
        {
            List<StatsVM> stats = new List<StatsVM>();


            var connectionFactory = new DBConnection();
            var conn = connectionFactory.GetConnection();


            var cmdText = "sp_select_Stats_by_UserID";


            var cmd = new SqlCommand(cmdText, conn);


            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@RankID", SqlDbType.NVarChar, 25);
            cmd.Parameters["@RankID"].Value = userStats;

            try
            {

                conn.Open();


                var reader = cmd.ExecuteReader();


                if (reader.HasRows)
                {
                    while (reader.Read())
                    {

                        var stat = new StatsVM();
                        stat.UserID = reader.GetInt32(0);
                        stat.RankID = reader.GetInt32(1);
                        stat.Ranks = reader.GetString(2);
                        stat.KDRatio = reader.GetDecimal(3);
                        stat.ACS = reader.GetInt32(4);

                        stats.Add(stat);

                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conn.Close();
            }

            return stats;
        }

        public List<string> SelectStatsByUserID(List<string> stats)
        {
            List<string> playerStats = new List<string>();


            var connectionFactory = new DBConnection();
            var conn = connectionFactory.GetConnection();


            var cmdText = "sp_select_Stats_by_UserID";


            var cmd = new SqlCommand(cmdText, conn);


            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@UserID", SqlDbType.NVarChar, 50);
            cmd.Parameters["@UserID"].Value = playerStats;

            try
            {
                conn.Open();

                var reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        playerStats.Add(reader.GetString(0));
                    }
                }
                else
                {
                    throw new ArgumentException("Invalid Map");
                }
            }
            catch (Exception up)
            {
                throw up;
            }
            finally
            {
                conn.Close();
            }

            return playerStats;
        }
    }
}


